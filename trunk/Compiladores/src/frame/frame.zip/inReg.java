package frame;

public class inReg extends Access {
	temp.Temp temp;
	inReg(temp.Temp t){
		temp = t;
	}
}
