package frame;

public abstract class Access {

	public void add(inReg inReg) {
		// TODO Auto-generated method stub
		
	}

	public void add(Access actual) {
		// TODO Auto-generated method stub
		
	}

}
