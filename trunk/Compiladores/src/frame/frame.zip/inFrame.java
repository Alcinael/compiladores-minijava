package frame;

public class inFrame extends Access {
	int offset;
	inFrame(int o){
		offset = o;
	}
	
}
