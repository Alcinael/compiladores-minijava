package util;

public class BoolList {
  public boolean head;
  public BoolList tail;
  public BoolList(boolean h, BoolList t) {head=h; tail=t;}
}