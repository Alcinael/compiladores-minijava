package temp;

public interface TempMap {public String tempMap(temp.Temp t);}
