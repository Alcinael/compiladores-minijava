package temp;

public class DefaultMap implements TempMap {
	public String tempMap(temp.Temp t) {
	   return t.toString();
	}

	public DefaultMap() {}
}